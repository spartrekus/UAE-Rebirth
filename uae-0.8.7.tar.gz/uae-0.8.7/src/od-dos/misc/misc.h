 /*
  * UAE - The Un*x Amiga Emulator
  *
  * DOS misc routines.
  *
  * (c) 1997 Gustavo Goedert
  */

void HandleOptions(void);
void SaveScreen(void);
void EnterDebug(void);
void LeaveDebug(void);
