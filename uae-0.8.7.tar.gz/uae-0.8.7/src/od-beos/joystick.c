 /* 
  * UAE - The Un*x Amiga Emulator
  * 
  * Joystick emulation stubs
  * 
  * Copyright 1997 Bernd Schmidt
  */

/* Dummy file, joystick routines are in beos.cpp */
