 /* 
  * UAE - The Un*x Amiga Emulator
  * 
  * Support for BeOS sound
  * 
  * Copyright 1996, 1997 Christian Bauer
  */

/* Dummy file, sound routines are in osdep/beos/cpp */
