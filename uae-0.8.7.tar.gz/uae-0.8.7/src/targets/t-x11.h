 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Target specific stuff, X11 version
  *
  * Copyright 1997 Bernd Schmidt
  */

#if SHM_SUPPORT_LINKS == 1
#define X11_SWITCH_SHM    { "T",	  "  -T           : Use MIT-SHM extension\n" },
#else
#define X11_SWITCH_SHM
#endif

#define TARGET_SPECIAL_OPTIONS \
    { "x",	  "  -x           : Hide X11 mouse cursor\n" }, \
    X11_SWITCH_SHM \
    { "L",	  "  -L           : Use low bandwidth mode\n" },


#if !defined USING_GTK_GUI
#define UNSUPPORTED_OPTION_G
#endif

#define OPTIONSFILENAME ".uaerc"
#define OPTIONS_IN_HOME

#define DEFPRTNAME "lpr"
#define DEFSERNAME "/dev/ttyS1"

#define PICASSO96_SUPPORTED

#define write_log write_log_standard
