 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Target specific stuff, Acorn RISC OS version
  *
  * Copyright 1997 Bernd Schmidt
  */

#define OPTIONSFILENAME ".uaerc"

/* ? */
#define UNSUPPORTED_OPTION_p
#define UNSUPPORTED_OPTION_I
