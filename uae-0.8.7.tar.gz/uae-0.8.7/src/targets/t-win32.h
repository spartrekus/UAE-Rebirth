 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Target specific stuff, Win32 version
  *
  * Copyright 1997 Mathias Ortmann
  */

#define NO_MAIN_IN_MAIN_C

#define UNSUPPORTED_OPTION_D
#define UNSUPPORTED_OPTION_l
#define UNSUPPORTED_OPTION_o

#define TARGET_SPECIAL_OPTIONS \
	{ "P:","  -P n         : Set UAE base priority\n" },

#define OPTIONSFILENAME "uae.rc"
#define OPTIONS_IN_HOME

#define DEFPRTNAME "LPT1"
#define DEFSERNAME "COM1"

#define PICASSO96_SUPPORTED
